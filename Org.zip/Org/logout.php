<!DOCTYPE html>

<?php
session_start();

		session_destroy();
		header('Location: /working/home/index.html');
?>

<html>
<head>
	<title></title>
</head>
<body>
</body>
</html>