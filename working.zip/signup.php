<?php
session_start();

  $uOrC = "Username";
  if(isset($_POST['uOrC'])){
    $uOrC = $_POST['uOrC'];
  }  
  if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){
    header('Location: logout.php');
  }
  else if(isset($_POST['signup'])){
    $conn = mysqli_connect("localhost", "root", "demosql", "temp");
    if (!$conn) {
        die("Connection failed: " . $conn->connect_error);
    } 

    $username = $_POST['username'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];

    $result = mysqli_query($conn,"SELECT * FROM user_info WHERE username = '$username'");
    if (mysqli_num_rows($result) == 0 && $password == $repassword){
      $res = mysqli_query($conn,"INSERT INTO user_info values('$username','$password')");
      header("Location: account_created.php");
    } 
    else if(mysqli_num_rows($result) != 0){
        // Username already exists
    }
    else if($password!=$repassword){
        // Passwords don't match
    }
  }
  else{
    $_SESSION['loggedin'] = false;
  }
?>

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Simple Login Form Template</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <div class="log-form">
  <h2>Create an account</h2>
  <br/>
                                          
<!--     <div class="dropdown">
      <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Dropdown Example
      <span class="caret"></span></button>
      <ul class="dropdown-menu">
        <li><a href="">User</a></li>
        <li><a href="#">Organisation</a></li>
      </ul>
    </div> -->
  <div class="dropdown" >

  <form method="post" action="signup.php">
  <select class="form-control" value="Select" name="uOrC" onchange="this.form.submit();">
    <option value="Username">User</option>
    <option value="Select">Select</option>
    <option value="Organisation name">Organisation</option>
  </select>

  </form>
  </div>  
<!--   <br/>
  <select width=50px class="form-control" id="select_1" name="thenumbers">
      <option value="UserType">Username</option>
      <option value="OrgType">Organisation name</option>
  </select> -->

  <form method="post" action="signup.php">
    <br/>
    <input type="text" name="username" title="username" data-validate = "Username is required" placeholder="<?php echo "$uOrC"  ?>" />
    <input type="password" name="password" title="password" placeholder="Password" />
    <input type="password" name="repassword" title="repassword" placeholder="Re-Enter Password" />
    <button type="submit" class="btn" name="signup" value="Sign Up">Sign Up</button>
    <a class="forgot" href="index.php">Already have an account? Login.</a>
  </form>
</div><!--end log form -->
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
 

</body>

</html>