A Pen created at CodePen.io. You can find this one at https://codepen.io/banunn/pen/AFnal.

 This is just a simple and easy to use form developed for any website that needs a useable login form. In the future, I would like to add form validation and tool tips. 

Inspired by: http://dribbble.com/shots/1153084-Login-Dialog-Freebie